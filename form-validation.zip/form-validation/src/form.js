import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Form.css';

const Form = () => {
  const [formValues, setFormValues] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    password: '',
    phoneNo: '',
    country: '',
    city: '',
    panNo: '',
    aadharNo: ''
  });

  const [formErrors, setFormErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validate = () => {
    let errors = {};
    if (!formValues.firstName.trim()) errors.firstName = 'First Name is required';
    if (!formValues.lastName.trim()) errors.lastName = 'Last Name is required';
    if (!formValues.username.trim()) errors.username = 'Username is required';
    if (!formValues.email) {
      errors.email = 'E-mail is required';
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      errors.email = 'E-mail is invalid';
    }
    if (!formValues.password) {
      errors.password = 'Password is required';
    } else if (formValues.password.length < 8) {
      errors.password = 'Password must be at least 8 characters long';
    }
    if (!formValues.phoneNo) {
      errors.phoneNo = 'Phone No. is required';
    } else if (!/^\+\d{1,3}\d{10}$/.test(formValues.phoneNo)) {
      errors.phoneNo = 'Phone No. must include country code and be 10 digits long';
    }
    if (!formValues.country) errors.country = 'Country is required';
    if (!formValues.city) errors.city = 'City is required';
    if (!formValues.panNo) {
      errors.panNo = 'Pan No. is required';
    } else if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(formValues.panNo)) {
      errors.panNo = 'Pan No. is invalid';
    }
    if (!formValues.aadharNo) {
      errors.aadharNo = 'Aadhar No. is required';
    } else if (!/^\d{12}$/.test(formValues.aadharNo)) {
      errors.aadharNo = 'Aadhar No. must be 12 digits long';
    }
    return errors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validate();
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      navigate('/summary', { state: formValues });
    }
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="form">
        <h1>Registration Form</h1>
        <div className="form-group">
          <label>First Name</label>
          <input type="text" name="firstName" value={formValues.firstName} onChange={handleChange} />
          {formErrors.firstName && <span className="error">{formErrors.firstName}</span>}
        </div>
        <div className="form-group">
          <label>Last Name</label>
          <input type="text" name="lastName" value={formValues.lastName} onChange={handleChange} />
          {formErrors.lastName && <span className="error">{formErrors.lastName}</span>}
        </div>
        <div className="form-group">
          <label>Username</label>
          <input type="text" name="username" value={formValues.username} onChange={handleChange} />
          {formErrors.username && <span className="error">{formErrors.username}</span>}
        </div>
        <div className="form-group">
          <label>E-mail</label>
          <input type="text" name="email" value={formValues.email} onChange={handleChange} />
          {formErrors.email && <span className="error">{formErrors.email}</span>}
        </div>
        <div className="form-group">
          <label>Password</label>
          <div className="password-container">
            <input type={showPassword ? 'text' : 'password'} name="password" value={formValues.password} onChange={handleChange} />
            <button type="button" onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
          {formErrors.password && <span className="error">{formErrors.password}</span>}
        </div>
        <div className="form-group">
          <label>Phone No.</label>
          <input type="text" name="phoneNo" value={formValues.phoneNo} onChange={handleChange} />
          {formErrors.phoneNo && <span className="error">{formErrors.phoneNo}</span>}
        </div>
        <div className="form-group">
          <label>Country</label>
          <select name="country" value={formValues.country} onChange={handleChange}>
            <option value="">Select Country</option>
            <option value="India">India</option>
            <option value="USA">USA</option>
          </select>
          {formErrors.country && <span className="error">{formErrors.country}</span>}
        </div>
        <div className="form-group">
          <label>City</label>
          <select name="city" value={formValues.city} onChange={handleChange}>
            <option value="">Select City</option>
            {formValues.country === 'India' && (
              <>
                <option value="Delhi">Delhi</option>
                <option value="Mumbai">Mumbai</option>
              </>
            )}
            {formValues.country === 'USA' && (
              <>
                <option value="New York">New York</option>
                <option value="Los Angeles">Los Angeles</option>
              </>
            )}
          </select>
          {formErrors.city && <span className="error">{formErrors.city}</span>}
        </div>
        <div className="form-group">
          <label>Pan No.</label>
          <input type="text" name="panNo" value={formValues.panNo} onChange={handleChange} />
          {formErrors.panNo && <span className="error">{formErrors.panNo}</span>}
        </div>
        <div className="form-group">
          <label>Aadhar No.</label>
          <input type="text" name="aadharNo" value={formValues.aadharNo} onChange={handleChange} />
          {formErrors.aadharNo && <span className="error">{formErrors.aadharNo}</span>}
        </div>
        <button type="submit" className="submit-button" disabled={Object.keys(formErrors).length > 0}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
