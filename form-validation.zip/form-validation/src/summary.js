import React from 'react';
import { useLocation } from 'react-router-dom';
import './Summary.css';

const Summary = () => {
  const location = useLocation();
  const { state } = location;

  return (
    <div className="summary-container">
      <h1>Summary</h1>
      <ul className="summary-list">
        <li><strong>First Name:</strong> {state.firstName}</li>
        <li><strong>Last Name:</strong> {state.lastName}</li>
        <li><strong>Username:</strong> {state.username}</li>
        <li><strong>E-mail:</strong> {state.email}</li>
        <li><strong>Phone No.:</strong> {state.phoneNo}</li>
        <li><strong>Country:</strong> {state.country}</li>
        <li><strong>City:</strong> {state.city}</li>
        <li><strong>Pan No.:</strong> {state.panNo}</li>
        <li><strong>Aadhar No.:</strong> {state.aadharNo}</li>
      </ul>
    </div>
  );
};

export default Summary;
